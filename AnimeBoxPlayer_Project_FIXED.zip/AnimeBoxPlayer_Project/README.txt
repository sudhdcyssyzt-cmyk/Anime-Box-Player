Anime Box Player - Android project

IMPORTANT:
This project intentionally uses a GitHub Actions workflow to build the APK in the cloud, so it does not require gradle-wrapper.jar or local Gradle on your phone.

To build the APK:
1. Upload the contents of this ZIP to a new GitHub repository (branch main).
2. Open the repository's Actions tab.
3. Select "Build Anime Box APK" and tap "Run workflow" if it did not start automatically.
4. When the workflow finishes successfully, open its run and download the artifact named AnimeBoxPlayer-debug-apk.
5. Extract the downloaded artifact ZIP to find app-debug.apk.

The project source is an Android WebView wrapper around app/src/main/assets/index.html. It plays direct video URLs you are authorized to use and hands magnet links to a compatible external app. A successful APK build has not been tested in this environment.
